﻿namespace Lab08_DeangeloIbrahim
{
    partial class frmMedical
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbData = new System.Windows.Forms.ListBox();
            this.btnAnalyze = new System.Windows.Forms.Button();
            this.dSMedicalRecords1400 = new Lab08_DeangeloIbrahim.DSMedicalRecords1400();
            this.medicalRecordsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medicalRecordsTableAdapter = new Lab08_DeangeloIbrahim.DSMedicalRecords1400TableAdapters.MedicalRecordsTableAdapter();
            this.tableAdapterManager = new Lab08_DeangeloIbrahim.DSMedicalRecords1400TableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.dSMedicalRecords1400)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalRecordsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lbData
            // 
            this.lbData.FormattingEnabled = true;
            this.lbData.Location = new System.Drawing.Point(12, 12);
            this.lbData.Name = "lbData";
            this.lbData.Size = new System.Drawing.Size(776, 368);
            this.lbData.TabIndex = 0;
            // 
            // btnAnalyze
            // 
            this.btnAnalyze.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnAnalyze.Location = new System.Drawing.Point(12, 396);
            this.btnAnalyze.Name = "btnAnalyze";
            this.btnAnalyze.Size = new System.Drawing.Size(108, 42);
            this.btnAnalyze.TabIndex = 1;
            this.btnAnalyze.Text = "Analyze";
            this.btnAnalyze.UseVisualStyleBackColor = false;
            this.btnAnalyze.Click += new System.EventHandler(this.btnAnalyze_Click);
            // 
            // dSMedicalRecords1400
            // 
            this.dSMedicalRecords1400.DataSetName = "DSMedicalRecords1400";
            this.dSMedicalRecords1400.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // medicalRecordsBindingSource
            // 
            this.medicalRecordsBindingSource.DataMember = "MedicalRecords";
            this.medicalRecordsBindingSource.DataSource = this.dSMedicalRecords1400;
            // 
            // medicalRecordsTableAdapter
            // 
            this.medicalRecordsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.MedicalRecordsTableAdapter = this.medicalRecordsTableAdapter;
            this.tableAdapterManager.UpdateOrder = Lab08_DeangeloIbrahim.DSMedicalRecords1400TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // frmMedical
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(808, 822);
            this.Controls.Add(this.btnAnalyze);
            this.Controls.Add(this.lbData);
            this.Name = "frmMedical";
            this.Text = " Medical Records";
            this.Load += new System.EventHandler(this.frmMedical_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dSMedicalRecords1400)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalRecordsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbData;
        private System.Windows.Forms.Button btnAnalyze;
        private DSMedicalRecords1400 dSMedicalRecords1400;
        private System.Windows.Forms.BindingSource medicalRecordsBindingSource;
        private DSMedicalRecords1400TableAdapters.MedicalRecordsTableAdapter medicalRecordsTableAdapter;
        private DSMedicalRecords1400TableAdapters.TableAdapterManager tableAdapterManager;
    }
}

