﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Lab08_DeangeloIbrahim
{
    public partial class frmMedical : Form
    {


        XElement BloodLabs = XElement.Load("BloodTests.xml");

        
        public struct secondbloodTests
        {
            public int PatID;
            public double Billrubins;
            public double Alk;
            public double SGOT;
            public double Albumin;
            public double Alive;
            public double Dead;
        }
        secondbloodTests[] Tests = new secondbloodTests[156]; //array for

           


            public double Bilrubin, AlkPhosphate, SGot, Albumin;

        private void btnAnalyze_Click(object sender, EventArgs e)
        {


            var Plist = from aPatient in dSMedicalRecords1400.MedicalRecords
                        let PID = aPatient.PatientID
                        select PID;
            lbData.Items.Clear();

            var Blist = from aResult in BloodLabs.Descendants("BloodTests") //Linq reading XML file
                        let PID = int.Parse(aResult.Element("PatientID").Value)
                        let BR = double.Parse(aResult.Element("Bilirubin").Value)
                        let ALK = double.Parse(aResult.Element("AlkPhosphate").Value)
                        let SGT = double.Parse(aResult.Element("SGot").Value)
                        let ALM = double.Parse(aResult.Element("Albumin").Value)
                        select new { PID, BR, ALK, SGT, ALM };
            int i = 0;

            foreach (var Alist in Blist) //as i increases by 1
                                        // it will put each data type into its own category
            {
                Tests[i].PatID = Alist.PID;
                Tests[i].Billrubins = Alist.BR;
                Tests[i].Alk = Alist.ALK;
                Tests[i].SGOT = Alist.SGT;
                Tests[i].Albumin = Alist.ALM;
                i++;
            }
            



            StreamReader BloodTests; //open txt file until its last line
            BloodTests = File.OpenText("BloodTests.txt");
            while (!BloodTests.EndOfStream)
            {
                string Line = BloodTests.ReadLine();
                string[] temp = Line.Split(','); //Splitting text with comma

                

                if (i != 75) //from Bloodtests.txt input the data into variables
                {
                    Tests[i-1].PatID = int.Parse((temp[0])); //Skip 75 because the other data goes up to 74
                    Tests[i-1].Billrubins = double.Parse((temp[1]));
                    Tests[i-1].Alk = double.Parse((temp[2]));
                    Tests[i-1].SGOT = double.Parse((temp[3]));
                    Tests[i-1].Albumin = double.Parse((temp[4]));
                }
                i++;

            }
                var Dlist = from aPatient in dSMedicalRecords1400.MedicalRecords
                            let PID = aPatient.PatientID
                            let Alive = aPatient.Alive
                            where (Alive == 2)
                            select PID; //select patients dead

            double BRSumAlive = 0, BRSumDead = 0, BRSquaredSumDead = 0,BRSquaredSumAlive = 0, BRGood = 0, BRDead = 0, ALKSumAlive = 0, ALKSumDead = 0 , ALKSquaredSumAlive = 0, AlkSquaredSumDead = 0, ALKGood = 0, ALKDead = 0;
                double SGSumAlive = 0, SGSumDead = 0, SGSquaredSumAlive = 0, SGSquaredSumDead = 0,  SGGood = 0, SGDead = 0, ALMSumAlive = 0, ALMSumDead = 0, ALMSquaredSumAlive = 0, ALMSquaredSumDead = 0, ALMGood = 0, ALMDead = 0;
               

            int k = 0;
           // foreach (var b in Blist) //select patients alive
                //{
                
                    var PInfo = from aPatient in dSMedicalRecords1400.MedicalRecords
                                let PID = aPatient.PatientID
                                let Alive = aPatient.Alive
                               // where (PID == b.PID)
                                select Alive;
            int g = 0;
            foreach (var j in PInfo)
            {
                Tests[g].Alive = j;


                g++;
            }

            for (int l = 0; l < Tests.Length; l++)
            {


                if (Tests[k].Billrubins != -99 && Tests[k].Alive == 2) // is not -99 and patient is alive
                {



                   BRSumAlive += Tests[k].Billrubins; //then add them to their blood type sum count and calculate alive
                    BRSquaredSumAlive += Math.Pow(Tests[k].Billrubins, 2);
                    BRGood++;
                }
                else if (Tests[k].Billrubins != -99 && Tests[k].Alive == 1)
                {

                    BRSumDead += Tests[k].Billrubins; //otherwise they are dead and put into the dead sum for the specific blood type and calculate
                    BRSquaredSumDead += Math.Pow(Tests[k].Billrubins, 2);
                    BRDead++;
                }



                if (Tests[k].Alk != -99 && Tests[k].Alive == 2) // is not -99 and patient is alive
                {


                    ALKSumAlive += Tests[k].Alk;
                    ALKSquaredSumAlive += Math.Pow(Tests[k].Alk, 2);
                    ALKGood++;
                }
                else if (Tests[k].Alk != -99 && Tests[k].Alive == 1)
                {
                    ALKSumDead += Tests[k].Alk;
                    AlkSquaredSumDead += Math.Pow(Tests[k].Alk, 2);
                    ALKDead++;

                }



                if (Tests[k].SGOT != -99 && Tests[k].Alive == 2)
                {



                    SGSumAlive += Tests[k].SGOT;
                    SGSquaredSumAlive += Math.Pow(Tests[k].SGOT, 2);
                    SGGood++;

                }
                else if (Tests[k].SGOT != -99 && Tests[k].Alive == 1)
                {
                    SGSumDead += Tests[k].SGOT;
                    SGSquaredSumDead += Math.Pow(Tests[k].SGOT, 2);
                    SGDead++;
                }





                if (Tests[k].Albumin != -99 && Tests[k].Alive == 2)
                {



                    ALMSumAlive += Tests[k].Albumin;
                    ALMSquaredSumAlive += Math.Pow(Tests[k].Albumin, 2);
                    ALMGood++;

                }
                else if (Tests[k].Albumin != -99 && Tests[k].Alive == 1)
                {
                    ALMSumDead += Tests[k].Albumin;
                    ALMSquaredSumDead += Math.Pow(Tests[k].Albumin, 2);
                    ALMDead++;

                }
                k++;
            }
          //  }

                double BRmeanAlive; //br alive/dead stdev
                double BRSTDevAlive;
            double BRSTDevDead; //Math for standard deviation and averages, 4x because 4 blood types
            double BRMeanDead;
                BRmeanAlive = BRSumAlive / BRGood;
                BRSTDevAlive = Math.Sqrt((BRSquaredSumAlive) / BRGood) - Math.Pow(BRmeanAlive, 2);
                BRMeanDead = BRSumDead / BRDead;
                BRSTDevDead = Math.Sqrt((BRSquaredSumDead) / BRDead) - Math.Pow(BRMeanDead, 2);





            double ALKmeanAlive;//alk alive stdev
                double ALKmeanDead;
                double ALKSTDevAlive;
                double ALKSTDevDead;

                ALKmeanDead = ALKSumDead / ALKDead;
                ALKmeanAlive = ALKSumAlive / ALKGood;
                ALKSTDevAlive = Math.Sqrt((ALKSquaredSumAlive) / ALKGood) - Math.Pow(ALKGood, 2);
                ALKSTDevDead = Math.Sqrt((AlkSquaredSumDead) / ALKDead) - Math.Pow(ALKDead, 2); //ALK STDev Alive/Dead

                double SgotMeanAlive;
                double SgotMeanDead;
                double SgotSTDevAlive;
                double SgotSTDevDead;

                SgotMeanAlive = SGSumAlive / SGGood; //Good = Alive
                SgotMeanDead = SGSumDead / SGDead;
                SgotSTDevAlive = Math.Sqrt((SGSquaredSumAlive) / SGGood) - Math.Pow(SGGood, 2);
                SgotSTDevDead = Math.Sqrt((SGSquaredSumDead) / SGDead) - Math.Pow(SGDead, 2); //SGOT STDev Alive/Dead

                double ALMmeanAlive;//alk alive stdev
                double ALMmeanDead;
                double ALMSTDevAlive;
                double ALMSTDevDead;

                ALMmeanDead = ALMSumAlive / ALMDead;
                ALMmeanAlive = ALMSumDead / ALMGood;
                ALMSTDevAlive = Math.Sqrt((ALKSquaredSumAlive) / ALKGood) - Math.Pow(ALKGood, 2);
                ALMSTDevDead = Math.Sqrt((AlkSquaredSumDead) / ALKDead) - Math.Pow(ALKDead, 2);


                lbData.Items.Add("Bilirubin Alive Mean -----> " + BRmeanAlive); //Listing Bilirubin standard deviations and averages
                lbData.Items.Add("Bilirubin St. Dev Alive -----> " + BRSTDevAlive);
                lbData.Items.Add("Bilirubin St. Dev Dead -----> " + BRSTDevDead);
                lbData.Items.Add("Bilirubin Dead Mean -----> " + BRMeanDead);

                lbData.Items.Add("Alkphosphate Alive Mean -----> " + ALKmeanAlive); //Alkphosphate
                lbData.Items.Add("Alkphosphate Dead Mean -----> " + ALKmeanDead);
                lbData.Items.Add("Alkphosphate St. Dev Alive -----> " + ALKSTDevAlive);
                lbData.Items.Add("Alkphosphate St. Dev Dead -----> " + ALKSTDevDead);

                lbData.Items.Add("Sgot Alive Mean -----> " + SgotMeanAlive); //SGot
                lbData.Items.Add("Sgot Dead Mean -----> " + SgotMeanDead);
                lbData.Items.Add("Sgot St. Dev Alive -----> " + SgotSTDevAlive);
                lbData.Items.Add("Sgot St. Dev Dead -----> " + SgotSTDevDead);

                lbData.Items.Add("Albumin Alive Mean -----> " + ALMmeanAlive); //Albumin
                lbData.Items.Add("Albumin Dead Mean -----> " + ALMmeanDead);
                lbData.Items.Add("Albumin St. Dev Alive -----> " + ALMSTDevAlive);
                lbData.Items.Add("Albumin St. Dev Dead -----> " + ALMSTDevDead);
                
            
        }

                    

        

        public frmMedical()
        {
            InitializeComponent();

           // int PatienID, Billrubin, Alk, SGot, Albumin;
        }

        private void medicalRecordsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.medicalRecordsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dSMedicalRecords1400);

        }

        private void frmMedical_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dSMedicalRecords1400.MedicalRecords' table. You can move, or remove it, as needed.
            this.medicalRecordsTableAdapter.Fill(this.dSMedicalRecords1400.MedicalRecords);

        }

       // private double MedicalR1(double R1, double R2, double R3)
       // {
           
           // var Alist = from aPatient in dSMedicalRecords1400.MedicalRecords
                       // let PID = aPatient.PatientID
                      //  let Alive = aPatient.Alive
                      //  where (Alive == 2)
                      //  select PID;
            
            


           // return MedicalR1;
        

    }
}
